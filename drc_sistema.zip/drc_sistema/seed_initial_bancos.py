"""
seed_initial_bancos.py — Carrega a primeira leva de preços (mês i0 inicial)
a partir do arquivo BANCOS_SABESP__SINAPI_E_TCPO.xlsx (3 abas: BANCO SABESP,
BANCO SINAPI, BANCO TCPO) para dentro do banco de dados local.

Uso:
    python seed_initial_bancos.py caminho/para/BANCOS_SABESP__SINAPI_E_TCPO.xlsx

Este script é idempotente: pode ser rodado de novo (ex.: para recarregar um
mês já existente) — os preços são sobrescritos (UPSERT) por (banco, i0, codigo).
"""
import sys
import pandas as pd

import db
from utils.import_utils import parse_sabesp, parse_sinapi, parse_tcpo, parse_i0_from_text


def seed(path):
    db.bootstrap()

    xls = pd.ExcelFile(path)

    # --- SABESP ---------------------------------------------------------
    raw = xls.parse("BANCO SABESP", header=None)
    titulo = raw.iloc[0, 1]
    i0_sabesp = parse_i0_from_text(titulo) or "2026-05-01"
    df_sabesp = parse_sabesp(raw, i0_sabesp)
    n1 = db.upsert_precos(df_sabesp, log_arquivo=f"seed inicial - {path}")
    print(f"SABESP: {n1} itens carregados para i0={i0_sabesp}")

    # --- SINAPI -----------------------------------------------------------
    raw = xls.parse("BANCO SINAPI", header=None)
    titulo = raw.iloc[0, 1]
    i0_sinapi = parse_i0_from_text(titulo) or "2026-05-01"
    df_sinapi = parse_sinapi(raw, i0_sinapi)
    n2 = db.upsert_precos(df_sinapi, log_arquivo=f"seed inicial - {path}")
    print(f"SINAPI: {n2} itens carregados para i0={i0_sinapi}")

    # --- TCPO ---------------------------------------------------------------
    raw = xls.parse("BANCO TCPO", header=0)
    df_tcpo = parse_tcpo(raw, i0=None)
    # TCPO pode ter mais de um i0 (coluna Data Preço); upsert por grupo
    n3 = 0
    for i0_val, grupo in df_tcpo.groupby("i0"):
        n3 += db.upsert_precos(grupo, log_arquivo=f"seed inicial - {path}")
    print(f"TCPO: {n3} itens carregados (i0 detectado por linha via 'Data Preço')")

    print("Seed inicial concluído.")


if __name__ == "__main__":
    caminho = sys.argv[1] if len(sys.argv) > 1 else "data/BANCOS_SABESP__SINAPI_E_TCPO.xlsx"
    seed(caminho)
